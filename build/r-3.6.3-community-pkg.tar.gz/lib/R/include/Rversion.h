/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 198147
#define R_NICK "Holding the Windsock"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "3"
#define R_MINOR  "6.3"
#define R_STATUS ""
#define R_YEAR   "2020"
#define R_MONTH  "02"
#define R_DAY    "29"
#define R_SVN_REVISION 77875
#define R_FILEVERSION    3,63,77875,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
